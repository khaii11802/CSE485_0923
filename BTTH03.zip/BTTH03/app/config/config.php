<?php
define('APP_ROOT', dirname(__FILE__, 3));
define('DOMAIN', 'http://localhost/KT@/');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'quanlybaihat');
